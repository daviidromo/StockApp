-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 30-05-2023 a las 17:12:53
-- Versión del servidor: 10.4.25-MariaDB
-- Versión de PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `stockapp`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `pro_id` int(11) NOT NULL,
  `pro_nombre` varchar(100) NOT NULL,
  `pro_cantidad` int(11) NOT NULL,
  `pro_unidad` varchar(50) NOT NULL,
  `pro_precio` double NOT NULL,
  `pro_cantidadMinima` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`pro_id`, `pro_nombre`, `pro_cantidad`, `pro_unidad`, `pro_precio`, `pro_cantidadMinima`) VALUES
(1, 'Harina', 23, 'Kilogramos', 15.99, 7),
(2, 'Levadura', 1, 'Kilogramos', 6.99, 0.33),
(3, 'Agua', 76, 'Litros', 0.5, 20),
(4, 'Sal', 1, 'Kilogramos', 2.99, 0.33),
(5, 'Aceite de oliva', 8, 'Litros', 9.99, 3),
(6, 'Tomate triturado', 1, 'Kilogramos', 2.99, 0.33),
(7, 'Mozzarella', 18, 'Kilogramos', 8.99, 7),
(8, 'Pepperoni', 9, 'Kilogramos', 14.99, 4),
(9, 'Champiñones', 3, 'Kilogramos', 6.99, 2),
(10, 'Cebolla', 2, 'Kilogramos', 1.99, 1),
(11, 'Pimiento', 2, 'Kilogramos', 2.99, 1),
(12, 'Salchicha italiana', 4, 'Kilogramos', 12.99, 3),
(13, 'Jamón', 1, 'Kilogramos', 9.99, 3),
(14, 'Aceitunas', 1, 'Kilogramos', 4.99, 0.33),
(15, 'Anchoas', 1, 'Kilogramos', 11.99, 0.33),
(16, 'Albahaca fresca', 1, 'Kilogramos', 6.99, 0.33),
(17, 'Orégano seco', 1, 'Kilogramos', 3.99, 0.33),
(18, 'Parmesano', 2, 'Kilogramos', 22.99, 1),
(19, 'Aceite en aerosol', 1, 'Kilogramos', 5.99, 0.33),
(20, 'Cajas de pizza', 227, 'Unidades', 24.99, 100),
(21, 'Bolsas de transporte', 45, 'Unidades', 3.99, 30),
(22, 'Servilletas', 4500, 'Unidades', 0.01, 2000),
(23, 'Cubiertos de plástico', 1000, 'Unidades', 7.99, 500),
(24, 'Vasos de papel', 1000, 'Unidades', 8.99, 500),
(25, 'Bebidas en lata', 227, 'Unidades', 0.5, 100),
(26, 'Fanta naranja', 50, 'Unidades', 0.7, 30),
(27, 'Coca Cola', 50, 'Unidades', 0.7, 30),
(28, 'Helados', 200, 'Unidades', 2.99, 100),
(29, 'Horno para pizza', 1, 'Unidad', 599.99, 0),
(30, 'Microondas', 1, 'Unidades', 50, 0),
(31, 'Cortadores de pizza', 5, 'Unidades', 5, 3),
(32, 'Tijeras de cocina', 5, 'Unidades', 3, 3),
(33, 'Escoba', 1, 'Unidades', 10, 1),
(34, 'Fregona', 2, 'Unidades', 10, 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
